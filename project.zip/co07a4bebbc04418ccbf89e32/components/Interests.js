import React from 'react';

export default function Interests() {
    return(
        <div className="interests">
            <h2>Interests</h2>
            <p>I am interested in cryptocurrencies. Decentralized autonomous organizations. Social-environmental projects. Skateboarding. Traveling.</p> 
        </div> 
    )
} 