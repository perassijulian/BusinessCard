import React from 'react';

export default function About() {
    return(
        <div className="about">
            <h2>About</h2>
            <p>I'm a fullstack developer that is currently learning web3. I am mostly advocated to React and Solidity. I made this template from scratch to reafirmate my React knowledge.</p> 
        </div>       
    )
} 